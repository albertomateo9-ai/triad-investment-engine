# Triad Investment Engine — free mobile deployment

This version is designed to be used as a real web app on an iPhone.

## Data source

It uses Twelve Data. The current Basic/free plan is documented as providing 800 API credits per day, with real-time US equities/ETFs and other free-plan data. Some international/fundamental datasets are restricted by plan or symbol, so the app handles missing data explicitly.

## Deploy for free

The easiest route is Streamlit Community Cloud:

1. Create a free GitHub account if you do not already have one.
2. Create a **public** GitHub repository, e.g. `triad-investment-engine`.
3. Upload:
   - `app.py`
   - `requirements.txt`
4. Open https://share.streamlit.io/
5. Sign in and create an app.
6. Select your GitHub repository and `app.py`.
7. Deploy.
8. Open the resulting `*.streamlit.app` address on your iPhone.
9. Add the page to the iPhone Home Screen if desired.

Streamlit documents Community Cloud as free and GitHub-connected.

## Twelve Data key

Create a free Twelve Data API key. Put it into the app's Settings field. The prototype does not hard-code your key into the source code.

## Important model note

This is not a recreation of the private methods of Warren Buffett, Chris Hohn or Stanley Druckenmiller. It is an educational composite:

- Buffett lens: quality / long-term economics
- Hohn lens: quality / cash generation / capital allocation
- Druckenmiller lens: momentum / trend / risk

The current Druckenmiller component is only a market-price proxy; it does not yet model the full macro regime (rates, inflation, liquidity, earnings revisions).

## Next upgrade

For a more serious research version, add:
- SEC EDGAR filings for US fundamentals
- FRED macro data
- point-in-time fundamentals
- true historical walk-forward backtests
- transaction costs and slippage
- portfolio-level risk and correlation
- alerts
